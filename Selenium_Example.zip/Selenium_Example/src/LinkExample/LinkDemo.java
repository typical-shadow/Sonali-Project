package LinkExample;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LinkDemo {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\learning\\Desktop\\Sonali\\MODULE-4\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.get("http:\\www.calculator.net/calorie-calculator.html");
		List<WebElement> listElement = (List<WebElement>) driver.findElements(By.tagName("a"));
		int len = listElement.size();
		System.out.println("Number of links : "+len);
		for(WebElement e: listElement) {
			System.out.println(e.getText());
	
		}
		
		WebElement BMILink = driver.findElement(By.linkText("BMI"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", BMILink);
	/*	Thread.sleep(2000);
		js.executeScript("history.go(0)");
		
		System.out.println("ENtire Page");
		String str = js.executeScript("return document.documentElement.innerText;").toString();
		System.out.println(str);
		*/
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");

	}

}
