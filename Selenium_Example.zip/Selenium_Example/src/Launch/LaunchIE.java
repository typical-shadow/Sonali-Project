package Launch;

import org.openqa.selenium.ie.InternetExplorerDriver;

public class LaunchIE {
	public static void main(String[] args) {
		System.setProperty("webdriver.ie.driver", "C:\\Users\\learning\\"
				+ "Desktop\\Sonali\\MODULE4\\IEDriverServer.exe");
		InternetExplorerDriver ie= new InternetExplorerDriver();
		ie.get("http://www.google.com");
	}
}
