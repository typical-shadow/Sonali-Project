package Launch;

import org.openqa.selenium.firefox.FirefoxDriver;

public class LaunchFirefox {
	public static void main(String[] args) {
		//System.setProperty("webdriver.gecko.driver", "C:\\Users\\learning\\Desktop\\Sonali\\MODULE4\\geckodriver.exe");
		FirefoxDriver firefox =new FirefoxDriver();
		firefox.get("http://www.google.com");
	}
}
