package Launch;

import org.openqa.selenium.chrome.ChromeDriver;

import javafx.beans.property.SetProperty;

public class LaunchChrome {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\learning\\Desktop\\Sonali\\VnV\\Module 4\\Advanced Selenium Libs\\WebDriver API\\chromedriver.exe");
		ChromeDriver driver= new ChromeDriver();
		driver.get("http:\\www.google.com");
	}
}
