package TimeCard;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.*;


public class TimeCardExample {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\learning\\"
				+ "Desktop\\Sonali\\MODULE4\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.get("http://talent.capgemini.com");
		WebElement username= driver.findElement(By.id("IDToken1"));
		username.sendKeys("sonbali");
		WebElement password= driver.findElement(By.id("IDToken2"));
		password.sendKeys("Sona@289");
		WebElement login = driver.findElement(By.className("Btn1Def"));
		login.click();
		WebElement TimeLink = driver.findElement(By.linkText("Time Card Application"));
		/*TimeLink.click();*/
//		WebElement TimeSummary = driver.findElement(By.className("level3 dynamic highlighted"));
//		TimeSummary.click();
/*		
		WebElement fin = driver.findElement(By.linkText("FINANCE"));
		WebElement timecard = fin.findElement(By.linkText("Timecard"));
		timecard.findElement(By.linkText("Timecard Summary")).click();
	*/
		driver.navigate().to(TimeLink.getAttribute("href"));
		Actions action= new Actions(driver);
		action.moveToElement(driver.findElement(By.linkText("FINANCE"))).build().perform();
		action.moveToElement(driver.findElement(By.linkText("Timecard"))).build().perform();
		action.moveToElement(driver.findElement(By.linkText("Timecard Summary"))).click().perform();
		
		
		
		
		
	}
}
