package seleniumgriddemo;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class GirdDemo {
	WebDriver driver;
	//help u set testcase environment
	DesiredCapabilities cap= null;
	//String browser = "chrome";
	//@Optional("chrome")
	@Parameters({"browser"})
	@Test
	public void TestGrid(String browser) throws MalformedURLException {
		//configure different browser
		if(browser.equals("chrome")) {
			cap = DesiredCapabilities.chrome();
			//cap.setBrowserName(browser);
			//cap.setPlatform(Platform.ANY);
			//cap.setVersion("");
		}
		else if(browser.equals("firefox")) {
			cap=DesiredCapabilities.firefox();
		}
		else if(browser.equals("ie")) {
			cap=DesiredCapabilities.internetExplorer();
		}
		driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"),cap);
		driver.get("http://www.calculator.net/calorie-calculator.html");
		WebElement ageTextBox=driver.findElement(By.id("cage"));
		ageTextBox.clear();
		ageTextBox.sendKeys("45");
		driver.close();
	}
}
