package Locator;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class LocateByClass {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\learning\\Desktop\\Sonali\\MODULE4\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.get("http:\\www.calculator.net/calorie-calculator.html");
		WebElement table = driver.findElement(By.className("cinfoT"));
		List<WebElement> rows = table.findElements(By.tagName("tr"));
		for (WebElement r : rows)
		{
			List<WebElement> cols= r.findElements(By.tagName("td"));
			for (WebElement c: cols){
				System.out.print(c.getText()+"\t");
			}
			System.out.println();
		}
		// change drop down list values
		//Identify dropdown list
		WebElement dd= driver.findElement(By.id("cactivity"));
		Select sel= new Select(dd);
		System.out.println("Default value : "+ sel.getFirstSelectedOption().getText() );
		sel.selectByIndex(2);
		Thread.sleep(2000);
		System.out.println("Changed value by Index :"+ sel.getFirstSelectedOption().getText());
		sel.selectByValue("1.725");
		Thread.sleep(2000);
		System.out.println("changed value by Value :" + sel.getFirstSelectedOption().getText());
		sel.selectByVisibleText("Very Active: intense exercise 6-7 times/week");
		Thread.sleep(2000);
		System.out.println("changed value using Visible text : " + sel.getFirstSelectedOption().getText());
		WebElement ageTextBox=driver.findElement(By.id("cage"));
		ageTextBox.clear();
		ageTextBox.sendKeys("45");
		System.out.println("Value of ageTextbox: "+ ageTextBox.getAttribute("value"));
		driver.findElement(By.linkText("BMI")).click();
		driver.findElement(By.partialLinkText("Watcher")).click();
		driver.navigate().back();
		driver.navigate().back();
		driver.navigate().forward();
		/*System.out.println("Value of ageTextbox: "+ ageTextBox.getAttribute("value"));
		driver.navigate().refresh();*/
	}

}
