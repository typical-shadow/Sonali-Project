package Locator;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class cssSelector {

	public static void main(String[] args) {
		/*System.setProperty("webdriver.ie.driver", "C:\\Users\\learning\\"
				+ "Desktop\\Sonali\\MODULE4\\IEDriverServer.exe");
		InternetExplorerDriver ie= new InternetExplorerDriver();
		ie.get("http://talent.capgemini.com");
		WebElement elem= ie.findElement(By.cssSelector("input[name='IDToken1']"));
		elem.sendKeys("./learning");
		*/
		System.setProperty("webdriver.chrome.driver","C:\\Users\\learning\\Desktop\\Sonali\\MODULE4\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		//driver.get("http://talent.capgemini.com");
		//setting value using cssSelector
		/*driver.findElement(By.cssSelector("input[name='IDToken1']")).sendKeys("./learning");*/
		//driver.navigate().to("http://www.google.com");
		driver.get("http://talent.capgemini.com");
		String expectedTitle ="Google";
		//fetching the title of page
		String actualTitle=driver.getTitle();
		System.out.println("Title of page: "+actualTitle);
		//comparing string
		if(expectedTitle.equals(actualTitle))
			System.out.println("Pass");
		else
			System.out.println("Fail");
		//get url
		System.out.println(driver.getCurrentUrl());
		//get page src
		//System.out.println(driver.getPageSource());
		WebElement UserTextBox=driver.findElement(By.id("IDToken1"));
		System.out.println("Value of name for UserName Textbox: "+ UserTextBox.getAttribute("type"));
		UserTextBox.sendKeys("sonbali");
		System.out.println("Value of username textbox : " + UserTextBox.getAttribute("value"));
	}

}
