package Locator;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class handleAlert {

	WebDriver driver;

	@Test
	public void testAlert() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\learning\\Desktop\\Sonali\\VnV\\Module 4\\Advanced Selenium Libs\\WebDriver API\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://demo.opencart.com/");
		
		/*****Alert*******/
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("alert('This is information Alert')");
		Alert alert = driver.switchTo().alert();
		String alertMsg = alert.getText();
		Thread.sleep(2000);
		//alert.accept();
		assertEquals(alertMsg, "This is information Alert");
		System.out.println("Alert success");
		
		/*********Confirm********/
		/*js.executeScript("confirm('Do you want to continue?')");
		Alert alert1 = driver.switchTo().alert();
		String ConfirmMsg = alert1.getText();
		Thread.sleep(2000);
		alert.accept();
		assertEquals(ConfirmMsg, "This is information Alert");
		System.out.println("Alert success");*/
		
	}

}
