package Locator;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocateByIdName {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\learning\\Desktop\\Sonali\\VnV\\Module 4\\Advanced Selenium Libs\\WebDriver API\\chromedriver.exe");
		ChromeDriver driver= new ChromeDriver();
		driver.get("http:\\www.calculator.net/calorie-calculator.html");
		driver.findElement(By.tagName("body")).sendKeys(Keys.chord(Keys.CONTROL,"a"));
		/*WebElement ageTextBox=driver.findElement(By.id("cage"));
		ageTextBox.clear();
		ageTextBox.sendKeys("45");
		ageTextBox.sendKeys(Keys.ENTER);
		System.out.println("Value of id for ageTextbox: "+ ageTextBox.getAttribute("id"));
		System.out.println("Value of name for ageTextbox: "+ ageTextBox.getAttribute("name"));
		System.out.println("Value of Type for ageTextbox: "+ ageTextBox.getAttribute("type"));
		System.out.println("Tagname of agetextbox: "+ ageTextBox.getTagName());
		List<WebElement> genderList = (List<WebElement>) driver.findElements(By.name("csex"));
		for(WebElement gender:genderList)
		{
			if(gender.getAttribute("value").equals("f"))
			{
				if(!gender.isSelected()) {
					gender.click();
					break;
				}
			}
		}
		ageTextBox.sendKeys(Keys.ENTER);*/
	}
}
