package Locator;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;



public class windowNav {
	WebDriver driver;

	@Test
	public void testAlert() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\learning\\Desktop\\Sonali\\VnV\\Module 4\\Advanced Selenium Libs\\WebDriver API\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.online.citibank.co.in/products-services/online-services/internet-banking.htm");
		driver.manage().window().maximize();
		String ParentWindowId= driver.getWindowHandle();
		System.out.println("Parent Window ID: "+ ParentWindowId);
		driver.findElement(By.xpath("//*[@id=\"main\"]/div[1]/div[2]/a")).click();
		Set<String> winids = driver.getWindowHandles();
		Iterator<String>  itr = winids.iterator();
		//get the first window id
		String mainwindid= itr.next().toString();
		//get the second window id
		String subwindid= itr.next().toString();
		System.out.println("MainWindow : "+ mainwindid);
		//switching to subwindow
		driver.switchTo().window(subwindid);
		driver.findElement(By.name("User_Id")).sendKeys("selenium");
		Thread.sleep(2000);
		driver.close(); //this is only closing subwindow
		//switching control to main window
		driver.switchTo().window(mainwindid);
		//identify an element in the mainwindow
		driver.findElement(By.id("topMnuinsurance")).click();
	}
}
