package Locator;

import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class WebDriverWaitEx {

	@Test
	public void webDriverEx() {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\learning\\Desktop\\Sonali\\VnV\\Module 4\\Advanced Selenium Libs\\WebDriver API\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://demo.opencart.com");
		
		WebDriverWait wait = new WebDriverWait(driver, 10);
		try {

			wait.until(ExpectedConditions
					.presenceOfElementLocated(By.xpath("//*[@id='menu']/div[2]/ul/li[3]/a")));
			WebElement componentmenu = driver.findElement(By.xpath("//*[@id='menu']/div[2]/ul/li[3]/a"));
			// move monitors element - mouse actions
			// create an instance of action class
			Actions action = new Actions(driver);
			action.moveToElement(componentmenu).click().build().perform();

		} catch (NoSuchElementException e) {
			System.out.println("components element not found");
		}
		WebElement monitors = driver.findElement(By.xpath("//*[@id=\"menu\"]/div[2]/ul/li[3]/div/div/ul/li[2]/a"));
		monitors.click();
		
	}
}
