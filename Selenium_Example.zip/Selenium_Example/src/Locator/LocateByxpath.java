package Locator;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocateByxpath {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\learning\\Desktop\\Sonali\\MODULE4\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.get("http:\\www.calculator.net/calorie-calculator.html");
		//WebElement label =driver.findElement(By.xpath(""))
		//System.out.println(label.getText());
		WebElement button = driver.findElement(By.xpath("//*[@id=\"content\"]/div[5]/table[4]/tbody/tr[3]/td[2]/input[2]"));
		button.click();
	}
}
