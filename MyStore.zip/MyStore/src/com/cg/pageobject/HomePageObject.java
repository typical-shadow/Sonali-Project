package com.cg.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePageObject {

		//homepage
		@FindBy(linkText="Sign in")
		private WebElement SignInLink;
		
		@FindBy(xpath="//*[@id=\"header_logo\"]/a")
		private WebElement LogoImgLink;
		
		@FindBy(xpath="//*[@id=\"homefeatured\"]/li[1]/div/div[1]/div/a[1]/img")
		private WebElement ProdImgLink;
		
		@FindBy(xpath="//*[@id=\"add_to_cart\"]/button/span")
		private WebElement AddToCartBtn;
		
		WebDriver driver;
		//PageFactory
		public HomePageObject(WebDriver driver)
		{
			this.driver=driver;
			PageFactory.initElements(driver, this);
		}
		
		public void ClickSignIn() {
			SignInLink.click();
		}
		
		public void GotoHomePage() {
			LogoImgLink.click();
		}
		
}
