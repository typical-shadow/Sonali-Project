package com.cg.pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class AddToCartPageObject {

	
		WebDriver driver;
		// PageFactory
		public AddToCartPageObject(WebDriver driver) {
			
			this.driver=driver;
			PageFactory.initElements(driver, this);
		}
	
		//add to cart    Faded Short Sleeve T-shirts
		/*@FindBy(xpath="//*[@id=\"homefeatured\"]/li[1]/div/div[1]/div/a[1]/img")*/
		@FindBy(xpath="(//img[@title='Faded Short Sleeve T-shirts'])[1]")
		private WebElement prodImgLink;
		
		@FindBy(name="Submit")
		private WebElement addToCartBtn;
		
		@FindBy(css="a[title='Proceed to checkout']")
		private WebElement ProceedToCheckOutBtn;
		
		@FindBy(partialLinkText="Proceed to checkout")
		private WebElement SummaryChckoutBtn;
		
		@FindBy(name="processAddress")
		private WebElement AddrChkOutBtn;
		
		@FindBy(id="cgv")
		private WebElement IagreeTermsChkBox;
		
		@FindBy(name="processCarrier")
		private WebElement ShipChkOutBtn;
		
		@FindBy(css="a[title='Pay by bank wire']")
		private WebElement PaymentMthdLink;
		
		@FindBy(xpath="//*[@id=\"cart_navigation\"]/button")
		private WebElement ConfirmOrderBtn;
		
		
		@FindBy(css="p[class='cheque-indent']")
		private WebElement confirmMsg;
		
		//functionality
		public void addToCartTest() throws InterruptedException {
			System.out.println("Here");
			Thread.sleep(10000);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			
			js.executeScript("window.scrollBy(0,500)");
			wait.until(ExpectedConditions.elementToBeClickable(prodImgLink));
			prodImgLink.click();
			
			Thread.sleep(2000);
			addToCartBtn.click();
			System.out.println("Added To Cart Successfully");
			
			
			Thread.sleep(2000);
			ProceedToCheckOutBtn.click();
			Thread.sleep(2000);
			
			js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
			wait.until(ExpectedConditions.elementToBeClickable(SummaryChckoutBtn));
			SummaryChckoutBtn.click();		
			
			js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
			wait.until(ExpectedConditions.elementToBeClickable(AddrChkOutBtn));
			AddrChkOutBtn.click();
		
			IagreeTermsChkBox.click();
			ShipChkOutBtn.click();
			
			PaymentMthdLink.click();
			js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
			wait.until(ExpectedConditions.elementToBeClickable(ConfirmOrderBtn));
			ConfirmOrderBtn.click();
			
			String expectedMsg="Your order on My Store is complete.";
			String actualMsg=confirmMsg.getText();
			Assert.assertEquals(actualMsg, expectedMsg);
			System.out.println("Order Confirmed Successfully");
		}
}
