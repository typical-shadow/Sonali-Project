package com.cg.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

public class SignInPageObject {

	@FindBy(id = "email")
	private WebElement emailTxtLogin; 	// emailtxt box for login

	@FindBy(id = "passwd")
	private WebElement passTxtBox;

	@FindBy(id = "SubmitLogin")
	private WebElement SignInBtn;

	WebDriver driver;
	// PageFactory
	public SignInPageObject(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void SigninTest() {
		
		emailTxtLogin.clear();
		emailTxtLogin.sendKeys("sonali289@g.co");

		passTxtBox.clear();
		passTxtBox.sendKeys("12345");

		SignInBtn.click();
	}
}
