package com.cg.pageobject;

import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class RegisterPageObject {

		//create acc
		@FindBy(id="email_create")
		private WebElement emailTxtBox;
			
		@FindBy(id="SubmitCreate")
		private WebElement createAccBtn;
			
		@FindBy(css="a[title='Log me out']")
		private WebElement logout;
		
		//registration
		@FindBy(name="id_gender")
		private List<WebElement> genderRadioBtn;
		
		@FindBy(id="customer_firstname")
		private WebElement firstNameTxtBox;
		
		@FindBy(id="customer_lastname")
		private WebElement lastNameTxtBox;
		
		@FindBy(id="passwd")
		private WebElement passTxtBox;
		
		@FindBy(id="days")
		private WebElement Datedd;
		
		@FindBy(id="months")
		private WebElement Monthdd;
		
		@FindBy(id="years")
		private WebElement yearsdd;
		
		@FindBy(id="newsletter")
		private WebElement newsLetterChk;
		
		@FindBy(id="optin")
		private WebElement spclOfferChk;
		
		@FindBy(id="company")
		private WebElement companyTxtBox;
		
		@FindBy(id="address1")
		private WebElement addr1TxtBox;
		
		@FindBy(id="address2")
		private WebElement addr2TxtBox;
		
		@FindBy(id="city")
		private WebElement cityTxtBox;
		
		@FindBy(id="id_state")
		private WebElement statedd;
		
		@FindBy(id="postcode")
		private WebElement postcodeTxtBox;
		
		@FindBy(id="uniform-id_country")
		private WebElement countrydd;
		
		@FindBy(id="phone_mobile")
		private WebElement phoneTxtBox;
		
		@FindBy(id="alias")
		private WebElement aliasTxtBox;
		
		@FindBy(id="submitAccount")
		private WebElement registerBtn;

		//Pagefactory
		WebDriver driver;
		public RegisterPageObject(WebDriver driver)
		{
			this.driver=driver;
			PageFactory.initElements(driver, this);
		}

/*		public void RegisterTest(String email,String gen,String fname,String lname,String pswd,String days,String months,String years,String company,String addr1,String addr2,String city,String state,String postcde,String ph,String aliasaddr) throws InterruptedException
		{
			
			emailTxtBox.clear();
			emailTxtBox.sendKeys(email);
			
			createAccBtn.click();
			
			Thread.sleep(2000);
			for(WebElement gender:genderRadioBtn)
			{
				if(gender.getAttribute("value").equals(gen))
				{
					if(!gender.isSelected()) {
						gender.click();
						break;
					}
				}
				else
				{
					if(!gender.isSelected()) {
						gender.click();
						break;
					}
				}	
			}
			
			Thread.sleep(2000);
			firstNameTxtBox.clear();
			firstNameTxtBox.sendKeys(fname);
			
			lastNameTxtBox.clear();
			lastNameTxtBox.sendKeys(lname);
			
			passTxtBox.clear();
			passTxtBox.sendKeys(pswd);
			
			Select selDate= new Select(Datedd);
			selDate.selectByValue(days);
			
			Select selMonth= new Select(Monthdd);
			selMonth.selectByValue(months);
			
			Select selYear= new Select(yearsdd);
			selYear.selectByValue(years);
			
			newsLetterChk.click();
			spclOfferChk.click();
			
			companyTxtBox.clear();
			companyTxtBox.sendKeys(company);
			
			addr1TxtBox.clear();
			addr1TxtBox.sendKeys(addr1);
			
			addr2TxtBox.clear();
			addr2TxtBox.sendKeys(addr2);
			
			cityTxtBox.clear();
			cityTxtBox.sendKeys(city);
			
			Select selState = new Select(statedd);
			selState.selectByVisibleText(state);
			
			postcodeTxtBox.clear();
			postcodeTxtBox.sendKeys(postcde);
			
			phoneTxtBox.clear();
			phoneTxtBox.sendKeys(ph);
			
			aliasTxtBox.clear();
			aliasTxtBox.sendKeys(aliasaddr);
			
			registerBtn.click();
			
			Thread.sleep(2000);
			logout.click();
		}
*/
		public void RegisterTest(Hashtable<String, String> tbl) throws InterruptedException {
			// TODO Auto-generated method stub
			

			emailTxtBox.clear();
			emailTxtBox.sendKeys(tbl.get("email"));
			
			createAccBtn.click();
			
			Thread.sleep(2000);
			for(WebElement gender:genderRadioBtn)
			{
				if(gender.getAttribute("value").equals(tbl.get("gender")))
				{
					if(!gender.isSelected()) {
						gender.click();
						break;
					}
				}
				else
				{
					if(!gender.isSelected()) {
						gender.click();
						break;
					}
				}	
			}
			
			Thread.sleep(2000);
			firstNameTxtBox.clear();
			firstNameTxtBox.sendKeys(tbl.get("firstname"));
			
			lastNameTxtBox.clear();
			lastNameTxtBox.sendKeys(tbl.get("lastname"));
			
			passTxtBox.clear();
			passTxtBox.sendKeys(tbl.get("password"));
			
			Select selDate= new Select(Datedd);
			selDate.selectByValue(tbl.get("days"));
			
			Select selMonth= new Select(Monthdd);
			selMonth.selectByValue(tbl.get("months"));
			
			Select selYear= new Select(yearsdd);
			selYear.selectByValue(tbl.get("years"));
			
			newsLetterChk.click();
			spclOfferChk.click();
			
			companyTxtBox.clear();
			companyTxtBox.sendKeys(tbl.get("company"));
			
			addr1TxtBox.clear();
			addr1TxtBox.sendKeys(tbl.get("address1"));
			
			addr2TxtBox.clear();
			addr2TxtBox.sendKeys(tbl.get("address2"));
			
			cityTxtBox.clear();
			cityTxtBox.sendKeys(tbl.get("city"));
			
			Select selState = new Select(statedd);
			selState.selectByVisibleText(tbl.get("state"));
			
			postcodeTxtBox.clear();
			postcodeTxtBox.sendKeys(tbl.get("postcode"));
			
			phoneTxtBox.clear();
			phoneTxtBox.sendKeys(tbl.get("mobile"));
			
			aliasTxtBox.clear();
			aliasTxtBox.sendKeys(tbl.get("aliasaddr"));
			
			registerBtn.click();
			
			Thread.sleep(2000);
			logout.click();

		}
}
