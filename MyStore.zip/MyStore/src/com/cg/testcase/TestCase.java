package com.cg.testcase;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Hashtable;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.cg.pageobject.AddToCartPageObject;
import com.cg.pageobject.HomePageObject;
import com.cg.pageobject.RegisterPageObject;
import com.cg.pageobject.SignInPageObject;
import com.cg.utilities.PropertyReader;
import com.cg.utilities.ReadFromExcel;

public class TestCase {

	SoftAssert soft = new SoftAssert();
	WebDriver driver;
	DesiredCapabilities cap = null;
	SignInPageObject signinObj = null;
	RegisterPageObject registerObject = null;
	HomePageObject HomeObject = null;
	AddToCartPageObject cartObject = null;

	@Parameters({ "browser" })
	@BeforeClass
	public void TestGrid(String browser) throws IOException {
		if (browser.equals("chrome")) {
			cap = DesiredCapabilities.chrome();
		} else if (browser.equals("firefox")) {
			cap = DesiredCapabilities.firefox();
		} else if (browser.equals("ie")) {
			cap = DesiredCapabilities.internetExplorer();
		}
		driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), cap);
		driver.get(PropertyReader.getProperty("url"));
		signinObj = new SignInPageObject(driver);
		
	}

	@Test(priority = 1)
	public void goToSignin() {
		HomeObject = new HomePageObject(driver);
		HomeObject.ClickSignIn();
		System.out.println("Home Page Loaded Suceesfully");
	}
	
	//@Test(priority = 3, dependsOnMethods = "TestRegister")
	@Test(priority=2)
	public void TestLogin() {
		String expectedTitle = "Login - My Store";
		signinObj.SigninTest();
		String actualTitle = driver.getTitle();
		System.out.println("User Signed in Successfully");
		soft.assertEquals(expectedTitle, actualTitle);
		HomeObject.GotoHomePage();
	}

	/*@Test(priority = 2, dataProvider = "read")
	public void TestRegister(Hashtable<String, String> tbl) throws InterruptedException {
		String expectedTitle="Login - My Store";
		String actualTitle=driver.getTitle();
		registerObject = new RegisterPageObject(driver);
		registerObject.RegisterTest(tbl);
		soft.assertEquals(expectedTitle,actualTitle);
		System.out.println("Registration successful");
		HomeObject.ClickSignIn();
	}
*/
	//@Test(priority = 4, dependsOnMethods="TestLogin")
	@Test(priority=3)
	public void TestAddtocart() throws InterruptedException {
		System.out.println(driver.getTitle());
		cartObject = PageFactory.initElements(driver, AddToCartPageObject.class);
		cartObject.addToCartTest();
	}

	@DataProvider
	public Object[][] read() throws IOException {
		String filename = "UserDetails.xlsx";
		String filepath = System.getProperty("user.dir") + "/src/com/cg/testdata";
		String sheetname = "users";
		return ReadFromExcel.ReadExcelData(filepath, filename, sheetname);
	}
	@AfterClass
	public void afterclass() {
		driver.quit();
	}
}
