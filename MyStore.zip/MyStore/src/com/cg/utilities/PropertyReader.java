package com.cg.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertyReader {

	public static Properties prop = null;
	public static FileInputStream inputStream = null;

	public static String getProperty(String propertyName) throws IOException {

		String propertyValue = "";
		inputStream = new FileInputStream(
				new File(System.getProperty("user.dir") + "/src/com/cg/config/config.properties"));
		prop = new Properties();
		prop.load(inputStream);
		propertyValue = prop.getProperty(propertyName);

		return propertyValue;

	}
}
