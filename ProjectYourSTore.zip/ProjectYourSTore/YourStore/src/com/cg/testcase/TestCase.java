package com.cg.testcase;

import org.junit.Ignore;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.cg.pageobject.HomePageObject;
import com.cg.pageobject.RegisterPageObject;
import com.cg.pageobject.SignInPageObject;

public class TestCase {

	WebDriver driver;
	SignInPageObject signinObj=null;
	RegisterPageObject registerObject=null;
	HomePageObject HomeObject=null;
	
	@BeforeClass
	public void beforeClass()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\learning\\Desktop\\Sonali\\MODULE-4\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.get("http://automationpractice.com/index.php	");
		//signinObj = new SignInPageObject(driver);
		registerObject = new RegisterPageObject(driver);
	}
	@Test(priority=1)
	public void goToSignin()
	{
		HomeObject = new HomePageObject(driver);
		HomeObject.ClickSignIn();
	}
	
//	@Ignore
//	@Test
//	public void TestLogin()
//	{
//		//SigninTest
//		signinObj.SigninTest();
//		System.out.println("Passed Signin");
//	}
	
	@Test(priority=2)
	public void TestRegister() throws InterruptedException
	{
		
		registerObject.RegisterTest();
	}
	
	
}
