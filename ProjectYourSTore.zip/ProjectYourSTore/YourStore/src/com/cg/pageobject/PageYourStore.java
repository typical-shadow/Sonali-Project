package com.cg.pageobject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PageYourStore {

	
	//homepage
	@FindBy(linkText="Sign in")
	private WebElement SignInLink;
	
	//create acc
	@FindBy(id="email_create")
	private WebElement emailTxtBox;
	
	@FindBy(id="SubmitCreate")
	private WebElement createAccBtn;
	
	
	//registration
	@FindBy(id="id_gender2")
	private WebElement genderRadioBtn;
	
	@FindBy(id="customer_firstname")
	private WebElement firstNameTxtBox;
	
	@FindBy(id="customer_lastname")
	private WebElement lastNameTxtBox;
	
	@FindBy(id="passwd")
	private WebElement passTxtBox;
	
	@FindBy(id="days")
	private WebElement Datedd;
	
	@FindBy(id="months")
	private WebElement Monthdd;
	
	@FindBy(id="years")
	private WebElement yearsdd;
	
	@FindBy(id="newsletter")
	private WebElement newsLetterChk;
	
	@FindBy(id="optin")
	private WebElement spclOfferChk;
	
	@FindBy(id="company")
	private WebElement companyTxtBox;
	
	@FindBy(id="address1")
	private WebElement addr1TxtBox;
	
	@FindBy(id="address2")
	private WebElement addr2TxtBox;
	
	@FindBy(id="city")
	private WebElement cityTxtBox;
	
	@FindBy(id="id_state")
	private WebElement statedd;
	
	@FindBy(id="postcode")
	private WebElement postcodeTxtBox;
	
	@FindBy(id="phone")
	private WebElement phoneTxtBox;
	
	@FindBy(id="alias")
	private WebElement aliasTxtBox;
	
	@FindBy(id="submitAccount")
	private WebElement registerBtn;
	
	
	//logo img for home pg
	@FindBy(xpath="//*[@id=\"header_logo\"]/a")
	private WebElement LogoImgLink;
	
	
}
