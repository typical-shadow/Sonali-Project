package com.cg.pageobject;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class RegisterPageObject {

	//create acc
			@FindBy(id="email_create")
			private WebElement emailTxtBox;
			
			@FindBy(id="SubmitCreate")
			private WebElement createAccBtn;
			
	
	//registration
		@FindBy(name="id_gender")
		private List<WebElement> genderRadioBtn;
		
		@FindBy(id="customer_firstname")
		private WebElement firstNameTxtBox;
		
		@FindBy(id="customer_lastname")
		private WebElement lastNameTxtBox;
		
		@FindBy(id="passwd")
		private WebElement passTxtBox;
		
		@FindBy(id="days")
		private WebElement Datedd;
		
		@FindBy(id="months")
		private WebElement Monthdd;
		
		@FindBy(id="years")
		private WebElement yearsdd;
		
		@FindBy(id="newsletter")
		private WebElement newsLetterChk;
		
		@FindBy(id="optin")
		private WebElement spclOfferChk;
		
		@FindBy(id="company")
		private WebElement companyTxtBox;
		
		@FindBy(id="address1")
		private WebElement addr1TxtBox;
		
		@FindBy(id="address2")
		private WebElement addr2TxtBox;
		
		@FindBy(id="city")
		private WebElement cityTxtBox;
		
		@FindBy(id="id_state")
		private WebElement statedd;
		
		@FindBy(id="postcode")
		private WebElement postcodeTxtBox;
		
		@FindBy(id="uniform-id_country")
		private WebElement countrydd;
		
		@FindBy(id="phone_mobile")
		private WebElement phoneTxtBox;
		
		@FindBy(id="alias")
		private WebElement aliasTxtBox;
		
		@FindBy(id="submitAccount")
		private WebElement registerBtn;

		//Pagefactory
		WebDriver driver;
		public RegisterPageObject(WebDriver driver)
		{
			PageFactory.initElements(driver, this);
		}

		public void RegisterTest() throws InterruptedException
		{
			
			emailTxtBox.clear();
			emailTxtBox.sendKeys("abc02@gmail.com");
			
			createAccBtn.click();
			
			Thread.sleep(2000);
			for(WebElement gender:genderRadioBtn)
			{
				if(gender.getAttribute("value").equals("2"))
				{
					if(!gender.isSelected()) {
						gender.click();
						break;
					}
				}
				else
				{
					if(!gender.isSelected()) {
						gender.click();
						break;
					}
				}	
			}
			
			Thread.sleep(2000);
			firstNameTxtBox.clear();
			firstNameTxtBox.sendKeys("Sonali");
			
			lastNameTxtBox.clear();
			lastNameTxtBox.sendKeys("Bali");
			
			passTxtBox.clear();
			passTxtBox.sendKeys("abc12345");
			
			Select selDate= new Select(Datedd);
			selDate.selectByVisibleText("24  ");
			
			Select selMonth= new Select(Monthdd);
			selMonth.selectByVisibleText("August ");
			
			Select selYear= new Select(yearsdd);
			selYear.selectByValue("2000");
			
			newsLetterChk.click();
			spclOfferChk.click();
			
			companyTxtBox.clear();
			companyTxtBox.sendKeys("capgemini");
			
			addr1TxtBox.clear();
			addr1TxtBox.sendKeys("street1, kings lane");
			
			addr2TxtBox.clear();
			addr2TxtBox.sendKeys("");
			
			cityTxtBox.clear();
			cityTxtBox.sendKeys("newyork");
			
			Select selState = new Select(statedd);
			selState.selectByVisibleText("New York");
			
			postcodeTxtBox.clear();
			postcodeTxtBox.sendKeys("00000");
			
			/*Select selCountry = new Select(countrydd);
			selState.selectByVisibleText("United States");*/
			
			phoneTxtBox.clear();
			phoneTxtBox.sendKeys("7894561230");
			
			aliasTxtBox.clear();
			aliasTxtBox.sendKeys("NewYork");
			
			registerBtn.click();
			
		}
}
